var searchData=
[
  ['file_0',['Flask APIs (Pre-Security, Single File)',['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html',1,'']]],
  ['finish_1',['finish',['../md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__finish.html',1,'POST /api/change-pen/finish'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md92',1,'POST /api/change-pen/finish']]],
  ['flask_20api_20docs_20pre_20security_2',['Flask API Docs (Pre-Security)',['../dir_0ab03e37850b887811c6cf6bc4806a83.html#autotoc_md331',1,'']]],
  ['flask_20apis_20pre_20security_20single_20file_3',['Flask APIs (Pre-Security, Single File)',['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html',1,'']]],
  ['focus_20adjust_4',['focus adjust',['../md_docs_2api-pre-security_2_p_o_s_t__api__scanner__focus__adjust.html',1,'POST /api/scanner/focus-adjust'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md158',1,'POST /api/scanner/focus-adjust']]]
];
