var searchData=
[
  ['upload_0',['upload',['../md_docs_2api-pre-security_2_p_o_s_t__api__upload.html',1,'POST /api/upload'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md170',1,'POST /api/upload']]]
];
