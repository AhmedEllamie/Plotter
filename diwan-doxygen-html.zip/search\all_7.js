var searchData=
[
  ['health_0',['health',['../md_docs_2api-pre-security_2_g_e_t__api__health.html',1,'GET /api/health'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md20',1,'GET /api/health']]]
];
