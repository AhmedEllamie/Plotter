var searchData=
[
  ['mainpage_2emd_0',['mainpage.md',['../mainpage_8md.html',1,'']]],
  ['manual_1',['manual',['../md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__manual.html',1,'POST /api/scanner/capture-manual'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md146',1,'POST /api/scanner/capture-manual']]],
  ['manual_20config_2',['manual config',['../md_docs_2api-pre-security_2_p_o_s_t__api__scanner__manual__config.html',1,'POST /api/scanner/manual-config'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md164',1,'POST /api/scanner/manual-config']]],
  ['max_20distance_3',['max distance',['../md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html',1,'POST /api/pen-max-distance'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md116',1,'POST /api/pen-max-distance']]],
  ['mjpg_4',['mjpg',['../md_docs_2api-pre-security_2_g_e_t__api__scanner__stream__mjpg.html',1,'GET /api/scanner/stream.mjpg'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md50',1,'GET /api/scanner/stream.mjpg']]]
];
