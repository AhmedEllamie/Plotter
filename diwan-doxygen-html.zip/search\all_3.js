var searchData=
[
  ['disconnect_0',['disconnect',['../md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html',1,'POST /api/disconnect'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md110',1,'POST /api/disconnect']]],
  ['distance_1',['distance',['../md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html',1,'POST /api/pen-max-distance'],['../md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md116',1,'POST /api/pen-max-distance']]],
  ['diwan_20signature_20api_20documentation_2',['Diwan Signature API Documentation',['../index.html',1,'']]],
  ['docs_20pre_20security_3',['Flask API Docs (Pre-Security)',['../dir_0ab03e37850b887811c6cf6bc4806a83.html#autotoc_md331',1,'']]],
  ['documentation_4',['Diwan Signature API Documentation',['../index.html',1,'']]]
];
