var indexSectionsWithContent =
{
  0: "abcdefghilmnprstuvw",
  1: "agmpr",
  2: "abcdefghilmnprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Pages"
};

