/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Diwan Signature API", "index.html", [
    [ "Diwan Signature API Documentation", "index.html", "index" ],
    [ "Flask APIs (Pre-Security, Single File)", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html", [
      [ "GET /api/capture/latest", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md2", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md3", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md4", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md5", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md6", null ]
      ] ],
      [ "GET /api/capture/latest/image", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md8", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md9", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md10", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md11", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md12", null ]
      ] ],
      [ "GET /api/config", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md14", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md15", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md16", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md17", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md18", null ]
      ] ],
      [ "GET /api/health", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md20", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md21", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md22", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md23", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md24", null ]
      ] ],
      [ "GET /api/requests", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md26", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md27", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md28", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md29", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md30", null ]
      ] ],
      [ "GET /api/requests/&lt;request_id&gt;", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md32", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md33", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md34", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md35", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md36", null ]
      ] ],
      [ "GET /api/scanner/capture/&lt;capture_id&gt;/result", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md38", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md39", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md40", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md41", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md42", null ]
      ] ],
      [ "GET /api/scanner/capture/&lt;capture_id&gt;/status", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md44", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md45", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md46", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md47", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md48", null ]
      ] ],
      [ "GET /api/scanner/stream.mjpg", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md50", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md51", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md52", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md53", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md54", null ]
      ] ],
      [ "GET /api/serial-port-check", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md56", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md57", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md58", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md59", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md60", null ]
      ] ],
      [ "GET /api/serial-ports", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md62", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md63", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md64", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md65", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md66", null ]
      ] ],
      [ "GET /api/status", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md68", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md69", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md70", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md71", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md72", null ]
      ] ],
      [ "POST /api/capture", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md74", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md75", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md76", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md77", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md78", null ]
      ] ],
      [ "POST /api/capture/request", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md80", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md81", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md82", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md83", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md84", null ]
      ] ],
      [ "POST /api/change-pen", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md86", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md87", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md88", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md89", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md90", null ]
      ] ],
      [ "POST /api/change-pen/finish", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md92", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md93", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md94", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md95", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md96", null ]
      ] ],
      [ "POST /api/change-pen/start", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md98", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md99", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md100", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md101", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md102", null ]
      ] ],
      [ "POST /api/connect", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md104", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md105", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md106", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md107", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md108", null ]
      ] ],
      [ "POST /api/disconnect", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md110", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md111", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md112", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md113", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md114", null ]
      ] ],
      [ "POST /api/pen-max-distance", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md116", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md117", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md118", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md119", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md120", null ]
      ] ],
      [ "POST /api/print", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md122", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md123", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md124", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md125", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md126", null ]
      ] ],
      [ "POST /api/print/bulk", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md128", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md129", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md130", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md131", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md132", null ]
      ] ],
      [ "POST /api/print/bulk/stop", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md134", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md135", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md136", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md137", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md138", null ]
      ] ],
      [ "POST /api/reset", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md140", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md141", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md142", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md143", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md144", null ]
      ] ],
      [ "POST /api/scanner/capture-manual", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md146", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md147", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md148", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md149", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md150", null ]
      ] ],
      [ "POST /api/scanner/capture/start", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md152", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md153", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md154", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md155", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md156", null ]
      ] ],
      [ "POST /api/scanner/focus-adjust", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md158", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md159", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md160", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md161", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md162", null ]
      ] ],
      [ "POST /api/scanner/manual-config", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md164", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md165", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md166", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md167", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md168", null ]
      ] ],
      [ "POST /api/upload", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md170", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md171", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md172", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md173", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md174", null ]
      ] ],
      [ "POST /api/void", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md176", [
        [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md177", null ],
        [ "What It Takes", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md178", null ],
        [ "Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md179", null ],
        [ "Error Response", "md_docs_2api-pre-security_2_a_l_l___a_p_i_s___p_r_e___s_e_c_u_r_i_t_y.html#autotoc_md180", null ]
      ] ]
    ] ],
    [ "GET /api/capture/latest", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest.html#autotoc_md182", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest.html#autotoc_md183", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest.html#autotoc_md184", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest.html#autotoc_md185", null ]
    ] ],
    [ "GET /api/capture/latest/image", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest__image.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest__image.html#autotoc_md187", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest__image.html#autotoc_md188", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest__image.html#autotoc_md189", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__capture__latest__image.html#autotoc_md190", null ]
    ] ],
    [ "GET /api/config", "md_docs_2api-pre-security_2_g_e_t__api__config.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__config.html#autotoc_md192", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__config.html#autotoc_md193", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__config.html#autotoc_md194", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__config.html#autotoc_md195", null ]
    ] ],
    [ "GET /api/health", "md_docs_2api-pre-security_2_g_e_t__api__health.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__health.html#autotoc_md197", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__health.html#autotoc_md198", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__health.html#autotoc_md199", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__health.html#autotoc_md200", null ]
    ] ],
    [ "GET /api/requests", "md_docs_2api-pre-security_2_g_e_t__api__requests.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__requests.html#autotoc_md202", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__requests.html#autotoc_md203", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__requests.html#autotoc_md204", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__requests.html#autotoc_md205", null ]
    ] ],
    [ "GET /api/requests/&lt;request_id&gt;", "md_docs_2api-pre-security_2_g_e_t__api__requests__request__id.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__requests__request__id.html#autotoc_md207", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__requests__request__id.html#autotoc_md208", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__requests__request__id.html#autotoc_md209", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__requests__request__id.html#autotoc_md210", null ]
    ] ],
    [ "GET /api/scanner/capture/&lt;capture_id&gt;/result", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__result.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__result.html#autotoc_md212", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__result.html#autotoc_md213", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__result.html#autotoc_md214", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__result.html#autotoc_md215", null ]
    ] ],
    [ "GET /api/scanner/capture/&lt;capture_id&gt;/status", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__status.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__status.html#autotoc_md217", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__status.html#autotoc_md218", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__status.html#autotoc_md219", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__scanner__capture__status.html#autotoc_md220", null ]
    ] ],
    [ "GET /api/scanner/stream.mjpg", "md_docs_2api-pre-security_2_g_e_t__api__scanner__stream__mjpg.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__scanner__stream__mjpg.html#autotoc_md222", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__scanner__stream__mjpg.html#autotoc_md223", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__scanner__stream__mjpg.html#autotoc_md224", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__scanner__stream__mjpg.html#autotoc_md225", null ]
    ] ],
    [ "GET /api/serial-port-check", "md_docs_2api-pre-security_2_g_e_t__api__serial__port__check.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__serial__port__check.html#autotoc_md227", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__serial__port__check.html#autotoc_md228", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__serial__port__check.html#autotoc_md229", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__serial__port__check.html#autotoc_md230", null ]
    ] ],
    [ "GET /api/serial-ports", "md_docs_2api-pre-security_2_g_e_t__api__serial__ports.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__serial__ports.html#autotoc_md232", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__serial__ports.html#autotoc_md233", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__serial__ports.html#autotoc_md234", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__serial__ports.html#autotoc_md235", null ]
    ] ],
    [ "GET /api/status", "md_docs_2api-pre-security_2_g_e_t__api__status.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_g_e_t__api__status.html#autotoc_md237", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_g_e_t__api__status.html#autotoc_md238", null ],
      [ "Response", "md_docs_2api-pre-security_2_g_e_t__api__status.html#autotoc_md239", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_g_e_t__api__status.html#autotoc_md240", null ]
    ] ],
    [ "POST /api/capture", "md_docs_2api-pre-security_2_p_o_s_t__api__capture.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__capture.html#autotoc_md242", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__capture.html#autotoc_md243", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__capture.html#autotoc_md244", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__capture.html#autotoc_md245", null ]
    ] ],
    [ "POST /api/capture/request", "md_docs_2api-pre-security_2_p_o_s_t__api__capture__request.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__capture__request.html#autotoc_md247", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__capture__request.html#autotoc_md248", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__capture__request.html#autotoc_md249", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__capture__request.html#autotoc_md250", null ]
    ] ],
    [ "POST /api/change-pen", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen.html#autotoc_md252", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen.html#autotoc_md253", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen.html#autotoc_md254", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen.html#autotoc_md255", null ]
    ] ],
    [ "POST /api/change-pen/finish", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__finish.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__finish.html#autotoc_md257", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__finish.html#autotoc_md258", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__finish.html#autotoc_md259", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__finish.html#autotoc_md260", null ]
    ] ],
    [ "POST /api/change-pen/start", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__start.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__start.html#autotoc_md262", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__start.html#autotoc_md263", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__start.html#autotoc_md264", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__change__pen__start.html#autotoc_md265", null ]
    ] ],
    [ "POST /api/connect", "md_docs_2api-pre-security_2_p_o_s_t__api__connect.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__connect.html#autotoc_md267", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__connect.html#autotoc_md268", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__connect.html#autotoc_md269", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__connect.html#autotoc_md270", null ]
    ] ],
    [ "POST /api/disconnect", "md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html#autotoc_md272", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html#autotoc_md273", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html#autotoc_md274", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html#autotoc_md275", null ]
    ] ],
    [ "POST /api/pen-max-distance", "md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html#autotoc_md277", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html#autotoc_md278", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html#autotoc_md279", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__pen__max__distance.html#autotoc_md280", null ]
    ] ],
    [ "POST /api/print", "md_docs_2api-pre-security_2_p_o_s_t__api__print.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__print.html#autotoc_md282", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__print.html#autotoc_md283", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__print.html#autotoc_md284", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__print.html#autotoc_md285", null ]
    ] ],
    [ "POST /api/print/bulk", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk.html#autotoc_md287", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk.html#autotoc_md288", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk.html#autotoc_md289", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk.html#autotoc_md290", null ]
    ] ],
    [ "POST /api/print/bulk/stop", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk__stop.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk__stop.html#autotoc_md292", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk__stop.html#autotoc_md293", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk__stop.html#autotoc_md294", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__print__bulk__stop.html#autotoc_md295", null ]
    ] ],
    [ "POST /api/reset", "md_docs_2api-pre-security_2_p_o_s_t__api__reset.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__reset.html#autotoc_md297", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__reset.html#autotoc_md298", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__reset.html#autotoc_md299", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__reset.html#autotoc_md300", null ]
    ] ],
    [ "POST /api/scanner/capture-manual", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__manual.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__manual.html#autotoc_md302", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__manual.html#autotoc_md303", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__manual.html#autotoc_md304", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__manual.html#autotoc_md305", null ]
    ] ],
    [ "POST /api/scanner/capture/start", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__start.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__start.html#autotoc_md307", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__start.html#autotoc_md308", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__start.html#autotoc_md309", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__capture__start.html#autotoc_md310", null ]
    ] ],
    [ "POST /api/scanner/focus-adjust", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__focus__adjust.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__focus__adjust.html#autotoc_md312", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__focus__adjust.html#autotoc_md313", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__focus__adjust.html#autotoc_md314", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__focus__adjust.html#autotoc_md315", null ]
    ] ],
    [ "POST /api/scanner/manual-config", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__manual__config.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__manual__config.html#autotoc_md317", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__manual__config.html#autotoc_md318", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__manual__config.html#autotoc_md319", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__scanner__manual__config.html#autotoc_md320", null ]
    ] ],
    [ "POST /api/upload", "md_docs_2api-pre-security_2_p_o_s_t__api__upload.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__upload.html#autotoc_md322", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__upload.html#autotoc_md323", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__upload.html#autotoc_md324", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__upload.html#autotoc_md325", null ]
    ] ],
    [ "POST /api/void", "md_docs_2api-pre-security_2_p_o_s_t__api__void.html", [
      [ "Pre-Security Behavior", "md_docs_2api-pre-security_2_p_o_s_t__api__void.html#autotoc_md327", null ],
      [ "What It Takes", "md_docs_2api-pre-security_2_p_o_s_t__api__void.html#autotoc_md328", null ],
      [ "Response", "md_docs_2api-pre-security_2_p_o_s_t__api__void.html#autotoc_md329", null ],
      [ "Error Response", "md_docs_2api-pre-security_2_p_o_s_t__api__void.html#autotoc_md330", null ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html",
"md_docs_2api-pre-security_2_p_o_s_t__api__disconnect.html#autotoc_md275"
];

var SYNCONMSG = 'click to disable panel synchronization';
var SYNCOFFMSG = 'click to enable panel synchronization';
var LISTOFALLMEMBERS = 'List of all members';